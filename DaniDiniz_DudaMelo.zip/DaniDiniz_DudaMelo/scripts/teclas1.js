
// Função para esconder todas as imagens
function esconderImagens() {
    const imagens = document.querySelectorAll('.imagem');
    imagens.forEach(imagem => {
        imagem.style.display = 'none'; // Esconde todas as imagens
    });

}


function mostrarImagemResultado() {
    const imagens = document.querySelectorAll('.imagem');
    imagens.forEach(imagem => {
        imagem.style.display = 'none'; // Esconde todas as imagens
    });
    // Mostra a imagem de resultado
    document.getElementById('imagemResultado').style.display = 'block';
}


// Função para simular o pressionamento da tecla
function simularTeclaEnter() {
    // Cria um novo evento de teclado
    const evento = new KeyboardEvent('keydown', {
        key: 'Enter',
        code: 'Enter',
        keyCode: 13, // Código da tecla Enter
        which: 13,
        bubbles: true, // Permite que o evento suba pela árvore DOM
        cancelable: true // Permite que o evento seja cancelado
    });

    // Despacha o evento no elemento desejado
    document.dispatchEvent(evento);
}
window.addEventListener('load', function() {
   // Chama a função para simular a tecla "Enter"
    simularTeclaEnter();
});


  

// Adiciona um listener para o evento de tecla pressionada
document.addEventListener('keydown', function(event) {
    esconderImagens(); // Esconde todas as imagens ao pressionar uma tecla
    // Verifica a tecla pressionada para aparecer a imagem certa
    if (event.key === 'ArrowLeft' || event.key === 's'  || event.key === 'S') {
        document.getElementById('imagemI').style.display = 'block';
    } else if (event.key === 'ArrowUp' || event.key === 'd'  || event.key === 'D') {
        document.getElementById('imagemA').style.display = 'block';
    } else if (event.key === 'ArrowDown' || event.key === 'j'  || event.key === 'J') {
        document.getElementById('imagemS').style.display = 'block';
    } else if (event.key === 'ArrowRight' || event.key === 'k'  || event.key === 'K') {
        document.getElementById('imagemB').style.display = 'block';
    }  else {
        mostrarImagemResultado(); // Mostra a imagem de resultado para outras teclas
    }
});



