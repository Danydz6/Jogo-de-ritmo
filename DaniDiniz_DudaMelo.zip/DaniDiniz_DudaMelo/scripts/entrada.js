document.getElementById('myForm').addEventListener('submit', function (event) {
    event.preventDefault(); // Impede o envio padrão do formulário

    // Mudar o fundo para um GIF após um timeout
    setTimeout(function () {
        document.body.style.backgroundSize = "cover";
        document.body.style.backgroundImage = "url('imagens/animacao.gif')";

        document.body.style.backgroundPosition = "center";



        // Redirecionar para outra página após o GIF 
        setTimeout(function () {
            window.location.href = 'file:///E:/2infonet/iw/DanyeDuda_pronto/DaniDiniz_DudaMelo/index.html'; // link pagina principal
        }, 12050); // Tempo para manter o GIF (3000 ms = 3 segundos)
    }, 100);
    // Tempo de espera antes de mostrar o GIF (1000 ms = 1 segundo)
});


document.getElementById('submit').addEventListener('click', function () {
    document.getElementById('myForm').style.display = 'none';

});
//tirar a div
