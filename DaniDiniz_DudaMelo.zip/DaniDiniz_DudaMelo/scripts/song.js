var ArrowLeft = {
  color: '#BB3990',
  next: 0,
  notes: [
    //primeira parte//
    { duration: 2, delay: -0.193 },
    { duration: 2, delay: 0.200 },
    { duration: 2, delay: 0.600 },
    { duration: 2, delay: 1.000 },
    { duration: 2, delay: 1.400 },
    { duration: 2, delay: 1.800 },
    { duration: 2, delay: 2.200 },
    { duration: 2, delay: 2.600 },
    { duration: 2, delay: 3.000 },
    { duration: 2, delay: 3.400 },
    { duration: 2, delay: 3.800 },
    { duration: 2, delay: 4.200 },
    { duration: 2, delay: 4.600 },
    { duration: 2, delay: 5.000 },
    { duration: 2, delay: 5.400 },
    { duration: 2, delay: 5.800 },
    { duration: 2, delay: 6.200 },
    { duration: 2, delay: 6.600 },
    { duration: 2, delay: 7.000 },
    { duration: 2, delay: 7.4 },
    { duration: 2, delay: 7.800 },
    { duration: 2, delay: 8.200 },
    { duration: 2, delay: 8.600 },
    //primeira parte//
    //pré terceira parte//
    { duration: 3, delay: 33.292 },

    { duration: 3, delay: 33.883 },


    //pré
    //TERCEIRA PARTE DA MUSICA 
    { duration: 3, delay: 35.575 },
    { duration: 3, delay: 36.728 },
    { duration: 3, delay: 38.559 },
    { duration: 3, delay: 39.465 },
    { duration: 3, delay: 41.205 },
    { duration: 3, delay: 42.400 },
    { duration: 3, delay: 43.400 },
    { duration: 3, delay: 44.760 },
    //
    { duration: 3, delay: 48.113 },//
    { duration: 3, delay: 48.716 },//
    { duration: 3, delay: 49.323 },//
    { duration: 3, delay: 49.943 },//
    //
    { duration: 3, delay: 52.921 },//
    { duration: 3, delay: 53.546 },//
    { duration: 3, delay: 54.144 },//
    { duration: 3, delay: 54.707 },//
    ///
    { duration: 3, delay: 57.792 },//
    { duration: 3, delay: 58.528 },//
    { duration: 3, delay: 60.386 },//














    //TERCEIRA PARTE DA MUSICA//
    //
    //parte final
    { duration: 3, delay: 88.685 },
    { duration: 3, delay: 89.539 },
    { duration: 3, delay: 90.158 }


  ]


};

var ArrowUp = {
  color: '#32DB6B',
  next: 0,
  notes: [
    //SEGUNDA PARTE DA MUSICA//
    { duration: 3, delay: 8.077 },

    { duration: 3, delay: 9.31 },
    { duration: 3, delay: 10.531 },
    { duration: 3, delay: 11.653 },
    { duration: 3, delay: 12.873 },
    { duration: 3, delay: 13.975 },
    { duration: 3, delay: 15.240 },
    { duration: 3, delay: 16.623 },
    { duration: 3, delay: 17.873 },
    { duration: 3, delay: 18.853 },
    { duration: 3, delay: 19.923 },
    { duration: 3, delay: 21.252 },
    { duration: 3, delay: 22.581 },
    { duration: 3, delay: 23.81 },
    { duration: 3, delay: 25.039 },
    { duration: 3, delay: 26.200 },
    { duration: 3, delay: 27.397 },
    { duration: 3, delay: 28.526 },
    { duration: 3, delay: 29.726 },
    { duration: 3, delay: 30.926 },
    { duration: 3, delay: 32.126 },
    //SEGUNDA PARTE DA MUSICA//
    //pre 3 parte

    { duration: 3, delay: 33.601 },
    { duration: 3, delay: 34.342 },

    //terceira parte
    { duration: 3, delay: 45.563 },//

    { duration: 3, delay: 46.027 },//

    { duration: 3, delay: 46.625 },//

    { duration: 3, delay: 47.225 },//
    ///
    { duration: 3, delay: 50.527 },//

    { duration: 3, delay: 51.116 },//

    { duration: 3, delay: 51.731 },//

    { duration: 3, delay: 52.222 },//
    ///
    { duration: 3, delay: 55.317 },//
    { duration: 3, delay: 56.035 },//
    { duration: 3, delay: 56.517 },

    { duration: 3, delay: 57.004 },//
















    //terceira parte
    //quarta parte//
    { duration: 3, delay: 63.409 },
    { duration: 3, delay: 64.609 },//
    { duration: 3, delay: 65.809 },
    { duration: 3, delay: 66.909 },
    { duration: 3, delay: 68.109 },
    { duration: 3, delay: 69.109 },
    { duration: 3, delay: 70.409 },
    { duration: 3, delay: 71.559 },
    { duration: 3, delay: 72.759 },
    { duration: 3, delay: 73.959 },
    { duration: 3, delay: 75.259 },
    { duration: 3, delay: 76.559 },
    { duration: 3, delay: 77.759 },
    { duration: 3, delay: 78.959 },
    { duration: 3, delay: 80.159 },
    { duration: 3, delay: 81.359 },
    { duration: 3, delay: 82.459 },
    { duration: 3, delay: 83.559 },
    { duration: 3, delay: 84.759 },
    { duration: 3, delay: 85.889 },
    { duration: 3, delay: 86.991 },
    { duration: 3, delay: 87.89 },





    //quarta parte//
    //parte final
    { duration: 3, delay: 88.934 },

  ]
};

var ArrowDown = {
  color: '#56EAE0',
  next: 0,
  notes: [
    //SEGUNDA PARTE DA MUSICA//
    { duration: 3, delay: 8.673 },
    { duration: 3, delay: 9.933 },
    { duration: 3, delay: 11.201 },
    { duration: 3, delay: 12.348 },
    { duration: 3, delay: 13.493 },
    { duration: 3, delay: 14.755 },
    { duration: 3, delay: 16.025 },
    { duration: 3, delay: 17.290 },
    { duration: 3, delay: 18.400 },
    { duration: 3, delay: 19.49 },
    { duration: 3, delay: 20.758 },
    { duration: 3, delay: 22.018 },
    { duration: 3, delay: 23.278 },
    { duration: 3, delay: 24.438 },
    { duration: 3, delay: 25.598 },
    { duration: 3, delay: 26.848 },
    { duration: 3, delay: 28.008 },
    { duration: 3, delay: 29.278 },
    { duration: 3, delay: 30.448 },
    { duration: 3, delay: 31.508 },
    { duration: 3, delay: 32.608 },
    //SEGUNDA PARTE DA MUSICA//
    //pre 3° parte//

    { duration: 3, delay: 33.731 },
    //terceira parte//
    { duration: 3, delay: 35.07 },//primeira nota
    { duration: 3, delay: 45.730 },//
    { duration: 3, delay: 46.342 },//
    { duration: 3, delay: 46.929 },//
    { duration: 3, delay: 47.419 },//
    ///
    { duration: 3, delay: 50.829 },//
    { duration: 3, delay: 51.413 },//
    { duration: 3, delay: 52.028 },//
    ///
    { duration: 3, delay: 55.021 },// 
    { duration: 3, delay: 55.625 },//
    { duration: 3, delay: 56.335 },//

    { duration: 3, delay: 56.819 },//

    { duration: 3, delay: 60.840 },//ultima nota

    //terceira parte//

    //QUARTA PARTE//
    { duration: 3, delay: 63.926 },
    { duration: 3, delay: 65.087 },//
    { duration: 3, delay: 66.348 },
    { duration: 3, delay: 67.509 },
    { duration: 3, delay: 68.67 },
    { duration: 3, delay: 69.97 },
    { duration: 3, delay: 71.2 },
    { duration: 3, delay: 72.3 },
    { duration: 3, delay: 73.4 },
    { duration: 3, delay: 74.559 },
    { duration: 3, delay: 75.859 },
    { duration: 3, delay: 77.159 },
    { duration: 3, delay: 78.259 },
    { duration: 3, delay: 79.359 },
    { duration: 3, delay: 80.559 },
    { duration: 3, delay: 81.659 },
    { duration: 3, delay: 82.859 },
    { duration: 3, delay: 84.159 },
    { duration: 3, delay: 85.259 },
    { duration: 3, delay: 86.360 },
    { duration: 3, delay: 87.401 },








    //quarta parte//
    //parte final
    //parte final
    { duration: 3, delay: 89.247 },

  ]
};

var ArrowRight = {
  color: '#E72731',
  next: 0,
  notes: [

    //primeira parte
    { duration: 2, delay: -0.400 },
    { duration: 2, delay: 0.070 },
    { duration: 2, delay: 0.470 },
    { duration: 2, delay: 0.870 },
    { duration: 2, delay: 1.270 },
    { duration: 2, delay: 1.670 },
    { duration: 2, delay: 2.070 },
    { duration: 2, delay: 2.470 },
    { duration: 2, delay: 2.870 },
    { duration: 2, delay: 3.270 },
    { duration: 2, delay: 3.670 },
    { duration: 2, delay: 4.070 },
    { duration: 2, delay: 4.470 },
    { duration: 2, delay: 4.870 },
    { duration: 2, delay: 5.270 },
    { duration: 2, delay: 5.670 },
    { duration: 2, delay: 6.070 },
    { duration: 2, delay: 6.470 },
    { duration: 2, delay: 6.870 },
    { duration: 2, delay: 7.270 },
    { duration: 2, delay: 7.670 },
    { duration: 2, delay: 8.070 },
    { duration: 2, delay: 8.470 },

    //primeira parte
    //p´re terceira parte
    { duration: 3, delay: 33.476 },

    { duration: 3, delay: 34.086 },
    //pre
    //TERCEIRA PARTE DA MUSICA//


    { duration: 3, delay: 36.436 },
    { duration: 3, delay: 38.035 },
    { duration: 3, delay: 38.99 },
    { duration: 3, delay: 40.480 },
    { duration: 3, delay: 41.633 },
    { duration: 3, delay: 42.966 },
    { duration: 3, delay: 44.045 },
    ///
    { duration: 3, delay: 48.40 },//
    { duration: 3, delay: 49.022 },//
    { duration: 3, delay: 49.629 },//
    ///
    { duration: 3, delay: 52.619 },//
    { duration: 3, delay: 53.250 },//
    { duration: 3, delay: 53.829 },//
    { duration: 3, delay: 54.443 },//
    ///
    { duration: 3, delay: 57.523 },//
    { duration: 3, delay: 58.021 },//
    { duration: 3, delay: 58.927 },//
    { duration: 3, delay: 59.820 },//







    //TERCEIRA PARTE DA MUSICA//
    //parte final
    { duration: 3, delay: 88.801 },
    { duration: 3, delay: 89.774 },
  ]
};

var song = {
  duration: 93,
  sheet: [ArrowLeft, ArrowUp, ArrowDown, ArrowRight]
};

